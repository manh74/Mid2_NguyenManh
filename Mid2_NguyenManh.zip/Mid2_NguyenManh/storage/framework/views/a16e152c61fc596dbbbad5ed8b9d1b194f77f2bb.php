<?php if(Session::has('flag')): ?>
    <div class="alert alert-<?php echo e(Session::get('flag')); ?>"><?php echo e(Session::get('message')); ?></div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\laravel\KT_NguyenManh2\resources\views////blocks/flag.blade.php ENDPATH**/ ?>
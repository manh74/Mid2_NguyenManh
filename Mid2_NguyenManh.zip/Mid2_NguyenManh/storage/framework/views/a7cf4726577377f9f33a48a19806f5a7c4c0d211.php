<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
<?php /**PATH D:\xampp\htdocs\laravel\KT_NguyenManh2\resources\views////blocks/alert.blade.php ENDPATH**/ ?>
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo $error; ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul> 
    </div>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\laravel\KT_NguyenManh\resources\views/blocks/error.blade.php ENDPATH**/ ?>
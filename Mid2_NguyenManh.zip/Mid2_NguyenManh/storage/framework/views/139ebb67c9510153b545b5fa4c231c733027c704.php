<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="public/css/style.css">
    <title>Tour</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <?php echo $__env->make('blocks.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <ul>
        <li style="margin-right: 200px"><img src="public/img/logo.png" alt=""></li>
        <li><a href="#"><b style="color:#ed0080">DU LỊCH</b></a></li>
        <li><a href="#">BOOK VÉ MÁY BAY</a></li>
        <li><a href="#">BOOK KHÁCH SẠN</a></li>
        <li><a href="#">DỊCH VỤ VISA</a></li>
        <li><a href="#">THUÊ XE</a></li>
        <li><a href="#">TIN TỨC</a></li>
        <li><a href="#">GIỚI THIỆU</a></li>
      </ul>
    <div class="container">
		<div class="">
			<div class="row">
				<?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4">
						<div class="card mb-2">
							<img height="200px" src="<?php echo $tour["image"]; ?>"
                            alt="<?php echo $tour["name"]; ?>">
                            <p class="type"><?php echo $tour["typetour"]; ?></p>
							<div class="card-body" >
								<div class="card-title" style="height: 60px; color: black"><b><?php echo $tour["name"]; ?></b></div>
								<div class="card-text" style="display: flex; justify-content: space-between">
                                    <div>
                                        <p>Lịch trình: <?php echo $tour["schedule"]; ?></p>
                                        <p>Khởi hành: <?php echo $tour["depart"]; ?></p>
                                        <p>Số chỗ còn nhận: <?php echo $tour["number"]; ?></p>
                                    </div>
                                    <div style="margin-top: 80px">
                                        <b style="color:#ed0080"><?php echo number_format($tour["price"]); ?>đ</b>
                                    </div>
                                </div>
							</div>
						</div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
        </div>
        <a href="<?php echo e(url('/add-tour/')); ?>" class="btn btn-xs btn-info pull-right">ADD</a>
	</div>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\laravel\KT_NguyenManh2\resources\views/tour.blade.php ENDPATH**/ ?>
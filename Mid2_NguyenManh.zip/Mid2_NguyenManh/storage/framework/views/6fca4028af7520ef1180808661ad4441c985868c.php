<div class="col-sm-12">
    <?php if(session()->get('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

      </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\xampp\htdocs\laravel\KT_NguyenManh2\resources\views/blocks/success.blade.php ENDPATH**/ ?>
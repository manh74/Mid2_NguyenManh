<?php $__env->startSection('content'); ?>
<div class="container">
    <br />
    <h3 align="center">Thống Kê Đơn Hàng</h3>
    <br />
  <div class="table-responsive">
   <table class="table table-bordered table-striped">
          <thead>
           <tr>
               <th>Name</th>
               <th>Address</th>
               <th>Date Order</th>
               <th>Date Order</th>
               <th>Payment</th>
               <th>Total</th>

           </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td><?php echo e($row->name); ?></td>

           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
  </div>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\KT_NguyenManh2\resources\views/page/admin.blade.php ENDPATH**/ ?>